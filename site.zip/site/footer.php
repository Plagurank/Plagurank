<footer>
        <div class="footer-docs">
            © 2023 «Style Loft». All Rights Reserved.  Phone Number: +7 (926)-(818)-39-59. e-mail: collegetsarytsino@come.ru
        </div>
</footer>


