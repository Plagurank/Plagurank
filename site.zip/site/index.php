<?php
session_start();
?>
<html lang="en">
<title>Главная | Style Loft</title>
<link rel="shortcut icon" href="img/er1.PNG" type="image/jpg">
<body>
<?php
include "header.php";
include "main.php";
include "footer.php";
?>
</body>
</html>



