<!-- Sidebar -->
<div class="sidebar" id="mySidebar">
<div class="side-header">

    <h5 style="margin-top:10px;">Здарова, Админчик</h5>
</div>

<hr style="border:1px solid; background-color:#8a7b6d; border-color:#3B3131;">
    <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
    <a href="#orders" onclick="showOrders()"><i class="fa fa-list"></i> Orders</a>
  
  <!---->
</div>
 
<div id="main">
    <button class="openbtn" onclick="openNav()"><i class="fa fa-home"></i></button>
</div>


