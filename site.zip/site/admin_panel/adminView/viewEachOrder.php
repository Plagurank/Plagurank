<div class="container">
<table class="table table-striped">
    <thead>
        <tr>
            <th>Номер Заказа</th>
            <th>Задание</th>
            <th>Дата Заказа</th>
            <th>Цена</th>
        </tr>
    </thead>
    <?php
        include_once "../config/dbconnect.php";
        $ID= $_GET['orderID'];
        //echo $ID;
        $sql="SELECT * from orders 
        where
        order_id=$ID";
        $result=$conn-> query($sql);
        $count=1;
        if ($result-> num_rows > 0){
            while ($row=$result-> fetch_assoc()) {
                $ID=$row['order_id'];
    ?>
                <tr>
                    <td><?=$row["order_id"]?></td>
                    <td><?=$row["task"]?></td>
                    <td><?=$row["date"]?></td>
                    <td><?=$row["price"]?></td>
                </tr>
    <?php
                $count=$count+1;
            }
        }else{
            echo "error";
        }
    ?>
</table>
</div>
