<section class="main">
    <div class="main-image-wrapper">
        <div class="leftside-text">
            <div class="upper-text">Мы создаем СТИЛЬ!</div>
            <div class="bottom-text">Вы можете лучший сайт различного функционала
            </div>
            <div class="leftside-btn">
                <div class="bottom-btn" id="st"><a href="store.php">Начать</a></div>
            </div>
        </div>
    </div>
    <div class="accessories-wrapper">
        <div class="accessories-text">Обширный каталог</div>
        <div class="accessories-image">
            <img src="img/cta-bg.jpg" alt="">
        </div>
    </div>
    </div>
</section>
